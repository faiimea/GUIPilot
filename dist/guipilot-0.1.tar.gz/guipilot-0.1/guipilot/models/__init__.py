from .detector.detector import Detector
from .ocr.ocr import OCR