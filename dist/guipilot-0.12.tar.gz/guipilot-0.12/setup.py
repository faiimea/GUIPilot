from setuptools import setup, find_packages

setup(
    name='guipilot',
    version='0.12',
    packages=find_packages(),
)